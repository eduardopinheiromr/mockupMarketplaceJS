const axios = require("axios");

const routes = ["/new-user", "/products/new-product", "/new-purchase"];

let products = require("./json/user.json");
axios
  .get("http://limitless-cove-49173.herokuapp.com/user/list")
  .then(function (response) {
    let providers = response.data.map((provider) => provider._id);

    products.map((product, index) => {
      setTimeout(() => {
        axios
          .post(
            "http://limitless-cove-49173.herokuapp.com/products/new-product",
            {
              providerID: providers[index],
              name: product.name,
              description: product.description,
              rating: product.rating,
              price: product.price,
              stock: product.stock,
            }
          )
          .then(function (response) {
            console.log(response);
          })
          .catch(function (error) {
            console.log(error);
          });
      }, 1000);
    });
  })
  .catch(function (error) {
    // handle error
    console.log(error);
  })
  .then(function () {
    // always executed
  });

// companyName: product.companyName,
// legalName: product.legalName,
// contact: product.contact,
// providerName: product.providerName,
// CNPJ: product.CNPJ,
// providerAdress: product.providerAdress,

//   axios
//     .get("http://limitless-cove-49173.herokuapp.com/user/list")
//     .then(function (response) {
//       response.map((product) => {
//         setTimeout(() => {
//           axios
//             .post("http://limitless-cove-49173.herokuapp.com/new-user", {
//               username: product.username,
//               fullName: product.fullName,
//               email: product.email,
//               password: product.password,
//               CPF: product.CPF,
//               contact: product.contact,
//               userAddress: product.userAddress,
//             })
//             .then(function (response) {
//               console.log(response);
//             })
//             .catch(function (error) {
//               console.log(error);
//             });
//         }, 1000);
//       });
//       console.log(response);
//     })
//     .catch(function (error) {
//       // handle error
//       console.log(error);
//     })
//     .then(function () {
//       // always executed
//     });
